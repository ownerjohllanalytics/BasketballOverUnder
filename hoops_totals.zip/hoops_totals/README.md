# Hoops Totals — basketball over/under calculator

Predicts a game's combined score and the probability of the over/under against a sportsbook line.

## Two phases (`data/config.json` → `"phase"`)

| Phase | What changes | What is locked |
|---|---|---|
| `offseason` | ML weights are re-trained (`python cli.py train history.csv`); rosters can be edited | — |
| `inseason`  | Rosters/injuries update daily (`python cli.py daily update.json` or the admin API) | **Weights are frozen** — `train()` raises an error |

Switch with `python cli.py phase inseason` / `offseason`.

## How the model works
1. Each roster is collapsed into minutes-weighted offensive/defensive ratings. Players marked `out` count 0%, `questionable` 50%, and the remaining players absorb the minutes. The share of rotation minutes missing is a feature.
2. Features: combined pace, each side's offense vs. the opponent's defense, rest days, back-to-backs, missing-minutes share, and a baseline `pace × efficiency` formula.
3. Ridge regression (numpy, closed form) learns the weights; 5-fold cross-validation gives a typical error (MAE) and residual spread.
4. `P(over)` = probability a normal distribution centred on the prediction, with the residual spread, exceeds the book line.

## Run it
```
pip install numpy
python make_sample_data.py          # demo data ONLY — replace with real data
python cli.py train data/history_sample.csv
python cli.py phase inseason
python cli.py predict DEN LAL --date 2026-11-02 --line 224.5
HOOPS_ADMIN_TOKEN=choose-a-secret python server.py     # website on :8000
```

## Daily in-season update (cron it)
`update.json`: `{"BOS": {"statuses": {"Jayson Tatum": "out"}, "last_game": "2026-11-01"}}`
```
curl -X POST https://yoursite/api/admin/roster -H "X-Admin-Token: $HOOPS_ADMIN_TOKEN" -d @update.json
```

## Using real data
- **Training CSV** columns = `engine.FEATURES` + `total` (final combined score). Build each row from the roster/ratings *as they stood before that game*, otherwise the model leaks the future.
- **Rosters** (`data/rosters.json`): per player `min`, `ortg`, `drtg`, `status`; per team `pace`, `last_game`. Fill from a stats source whose terms allow public use (e.g. an NBA stats API or a licensed feed).

## Putting it on a public website
- `engine.py` has no web dependencies, so it ports anywhere. `server.py` is stdlib-only; `app_fastapi.py` is an equivalent FastAPI wrapper (not tested here).
- Only `/api/admin/roster` writes anything, and it needs the secret token. Serve over HTTPS and add rate limiting at your host/proxy.
- JSON files are fine for one server; for multiple instances move `data/` to a shared database or object store.
- Include a "for entertainment/information only; not betting advice" notice, and check gambling-related rules for your jurisdiction.
- Honest expectation: sportsbook lines are very efficient. Treat this as a solid, transparent baseline, not a money machine.
